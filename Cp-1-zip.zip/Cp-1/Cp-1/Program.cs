﻿// See https://aka.ms/new-console-template for more information
using System.Xml.Linq;

Console.WriteLine("Hello, World!");
using BlogAnime.Lib;

var u1 = new Usuario("Jhonatan", new DateTime(2000, 5, 10), "Jhow", "1234");
u1.MostrarDados();

Console.WriteLine();

var a1 = new Anime("Naruto", 220);
a1.MostrarAnime();

Console.WriteLine($"\nTotal de Usuários: {Usuario.TotalUsuarios}");
Console.WriteLine("\nPressione Enter para sair...");
Console.ReadLine();
