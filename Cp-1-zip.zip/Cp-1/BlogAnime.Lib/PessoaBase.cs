using System;

namespace BlogAnime.Lib
{
    public abstract class PessoaBase
    {
        public string Nome { get; set; } = string.Empty;          // public
        protected DateTime DataNascimento { get; set; }          // protected
        internal int Id { get; set; }                            // internal
        private protected string Email { get; set; } = "";       // private protected

        public PessoaBase(string nome, DateTime dataNascimento)
        {
            Nome = nome;
            DataNascimento = dataNascimento;
        }

        public virtual void MostrarDados()
        {
            Console.WriteLine($"Nome: {Nome}");
            Console.WriteLine($"Data de Nascimento: {DataNascimento:dd/MM/yyyy}");
        }
    }
}
