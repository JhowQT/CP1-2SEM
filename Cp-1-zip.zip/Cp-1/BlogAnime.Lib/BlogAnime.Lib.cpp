// BlogAnime.Lib.cpp : Define as funções da biblioteca estática.
//

#include "pch.h"
#include "framework.h"

// TODO: Este é um exemplo de uma função de biblioteca
void fnBlogAnimeLib()
{
}
