using System;

namespace BlogAnime.Lib
{
    public class Anime
    {
        public string Titulo { get; set; } = "";
        public int Episodios { get; set; }

        public Anime(string titulo, int episodios)
        {
            Titulo = titulo;
            Episodios = episodios;
        }

        public void MostrarAnime()
        {
            Console.WriteLine($"Anime: {Titulo} ({Episodios} epis�dios)");
        }
    }
}
