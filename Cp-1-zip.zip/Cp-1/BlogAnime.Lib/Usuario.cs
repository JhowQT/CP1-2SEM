using System;

namespace BlogAnime.Lib
{
    public class Usuario : PessoaBase
    {
        private string Senha { get; set; } = "";                 // private
        protected internal string Nickname { get; set; } = "";   // protected internal
        public static int TotalUsuarios { get; private set; }    // static

        public Usuario(string nome, DateTime dataNascimento, string nickname, string senha)
            : base(nome, dataNascimento)
        {
            Nickname = nickname;
            Senha = senha;
            TotalUsuarios++;
        }

        // override para polimorfismo
        public override void MostrarDados()
        {
            base.MostrarDados();
            Console.WriteLine($"Nickname: {Nickname}");
        }
    }
}
